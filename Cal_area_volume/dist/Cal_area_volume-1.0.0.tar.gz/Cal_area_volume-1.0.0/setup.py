from distutils.core import setup

setup(
    name='Cal_area_volume',
    version='1.0.0',
    py_modules=['Cal_area_volume'],
    author='chipoo',
    author_email='250795737@qq.com',
    url='D:/Py repo/Cal_area_volume',
    description='Calculate the volume area.'
)
